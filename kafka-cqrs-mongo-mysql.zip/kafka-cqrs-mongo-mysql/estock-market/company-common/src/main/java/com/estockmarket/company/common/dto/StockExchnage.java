package com.estockmarket.company.common.dto;

public enum StockExchnage {
	BSE, NSE
}
