package com.estockmarket.company.command.api;

import java.time.LocalDateTime;

import com.estockmarket.cqrscore.messages.BaseCommand;

import lombok.Data;

@Data
public class AddStockPrice extends BaseCommand{
	
	private String companyCode;
	private double stockPrice;
	private LocalDateTime dateCreated;
	
}
