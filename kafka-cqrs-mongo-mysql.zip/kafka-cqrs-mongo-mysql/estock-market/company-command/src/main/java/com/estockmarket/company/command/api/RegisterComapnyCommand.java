package com.estockmarket.company.command.api;

import java.time.LocalDateTime;

import com.estockmarket.company.common.dto.StockExchnage;
import com.estockmarket.cqrscore.messages.BaseCommand;

import lombok.Data;

@Data
public class RegisterComapnyCommand extends BaseCommand{
	
	private String companyCode;
	private String companyName;
	private String companyCEO;
	private double companyTurnover;
	private String website;
	private StockExchnage stockExng;
	private String createdBy;
	private LocalDateTime dateCreated;
	private boolean isActive;
	private double currentStockPrice;
}
